HƯỚNG DẪN BÀI LAB: steg_lsb_stereo_diff
========================================

Bài lab này giúp sinh viên khám phá kỹ thuật LSB Differential Steganography
áp dụng trên file âm thanh stereo WAV.

KHỞI ĐỘNG:
  labtainer steg_lsb_stereo_diff

THỰC HÀNH (trên container analyst):
  Bước 1 - Kiểm tra cấu trúc WAV stereo:
    python3 ~/steg_lab/inspect_stereo.py
    => Tạo: steg_lab/stereo_info.txt

  Bước 2 - Nhúng thông điệp (LSB Differential):
    python3 ~/steg_lab/embed_diff.py
    => Tạo: steg_lab/stego_diff.wav

  Bước 3 - Trích xuất thông điệp:
    python3 ~/steg_lab/extract_diff.py
    => Tạo: steg_lab/extracted_msg.txt

  Bước 4 - Kiểm định Chi-square so sánh:
    python3 ~/steg_lab/chi_square_compare.py
    => Tạo: steg_lab/chi_compare.txt

  Bước 5 - Viết báo cáo:
    python3 ~/steg_lab/viet_bao_cao.py
    => Tạo: steg_lab/bao_cao.txt

KIỂM TRA KẾT QUẢ:
  checkwork

KẾT THÚC:
  stoplab steg_lsb_stereo_diff

KHỞI ĐỘNG LẠI:
  labtainer -r steg_lsb_stereo_diff
