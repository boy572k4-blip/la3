Lab: steg_lsb_stereo_diff

The terminal starts in:
  /home/ubuntu/steg_lab

Run and complete the lab in order:
  python3 generate_stereo.py
  python3 inspect_stereo.py
  nano embed_diff.py
  python3 embed_diff.py
  nano extract_diff.py
  python3 extract_diff.py
  python3 chi_square_compare.py
  python3 viet_bao_cao.py
  nano analysis_answer.txt

Checkwork markers:
  INSPECT_STEREO_DONE
  EMBED_DIFF_DONE
  EXTRACT_DIFF_DONE
  CHI_COMPARE_DONE
  STEREO_DIFF_REPORT_DONE
  STUDENT_STEREO_DIFF_DONE
