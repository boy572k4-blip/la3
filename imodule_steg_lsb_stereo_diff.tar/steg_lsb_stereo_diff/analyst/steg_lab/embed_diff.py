#!/usr/bin/env python3
"""
Step 2-3: embed a message into a stereo WAV file using LSB Differential.

Student task:
  Complete adjust_for_bit().
  Hidden bit = parity of (L[i] - R[i]).
"""
import os
import struct
import sys
import wave

STEG_DIR = "/home/ubuntu/steg_lab"
WAV_IN = os.path.join(STEG_DIR, "stereo_input.wav")
WAV_OUT = os.path.join(STEG_DIR, "stego_diff.wav")
RESULT_FILE = os.path.join(STEG_DIR, "embed_result.txt")
SENTINEL = "||END||"


def adjust_for_bit(L_val, R_val, bit):
    # TODO: Student completes this function.
    # Requirement:
    #   diff = L_val - R_val
    #   if diff parity already equals bit, return R_val
    #   otherwise adjust R_val by +1
    #   if +1 would exceed 32767, use -1 instead
    raise NotImplementedError("Complete adjust_for_bit() first")


def embed_diff(wav_in, wav_out, message):
    sentinel_msg = message + SENTINEL
    bits = [int(b) for byte in sentinel_msg.encode("utf-8") for b in f"{byte:08b}"]

    with wave.open(wav_in, "r") as f:
        params = f.getparams()
        frames = f.readframes(f.getnframes())

    if params.nchannels != 2:
        raise ValueError("Input WAV must be stereo")

    total_samples = len(frames) // 2
    samples = list(struct.unpack(f"<{total_samples}h", frames))
    L = samples[0::2]
    R = list(samples[1::2])

    if len(bits) > len(R):
        raise ValueError("Message is too long for this WAV file")

    modified = 0
    for i, bit in enumerate(bits):
        new_r = adjust_for_bit(L[i], R[i], bit)
        if new_r != R[i]:
            modified += 1
        R[i] = new_r

    merged = []
    for l, r in zip(L, R):
        merged.extend([l, r])

    new_frames = struct.pack(f"<{len(merged)}h", *merged)
    with wave.open(wav_out, "w") as fout:
        fout.setparams(params)
        fout.writeframes(new_frames)

    return len(bits), modified


def main():
    message = "MatKhauBiMat"
    if len(sys.argv) > 1:
        message = sys.argv[1]

    lines = []
    try:
        bits_used, modified = embed_diff(WAV_IN, WAV_OUT, message)
        lines.extend([
            "EMBED_DIFF_DONE",
            f"message={message}",
            f"bits_embedded={bits_used}",
            f"right_channel_samples_modified={modified}",
            "output_file=stego_diff.wav",
        ])
        print(f"[OK] Embedded {bits_used} bits into {WAV_OUT}")
        print(f"[OK] Modified {modified} right-channel samples")
    except Exception as exc:
        lines.extend([
            "EMBED_DIFF_FAILED",
            f"error={type(exc).__name__}: {exc}",
        ])
        print(f"[ERROR] {exc}")

    with open(RESULT_FILE, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"[OK] result saved to: {RESULT_FILE}")


if __name__ == "__main__":
    main()
