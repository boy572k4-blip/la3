#!/usr/bin/env python3
"""
Bước 2 & 3: Nhúng thông điệp vào WAV stereo bằng kỹ thuật LSB Differential
Nguyên lý: Bit ẩn = parity của hiệu (L[i] - R[i])
  - Bit = 0 => điều chỉnh R sao cho (L-R) CHẴN
  - Bit = 1 => điều chỉnh R sao cho (L-R) LẺ
  - Chỉ thay đổi ±1 trên kênh R để bảo toàn chất lượng âm thanh
"""
import wave
import struct
import os
import sys

STEG_DIR = '/home/ubuntu/steg_lab'
WAV_IN   = os.path.join(STEG_DIR, 'stereo_input.wav')
WAV_OUT  = os.path.join(STEG_DIR, 'stego_diff.wav')
SENTINEL = '||END||'


def adjust_for_bit(L_val, R_val, bit):
    """Trả về R_val đã điều chỉnh để parity(L-R) == bit"""
    diff = L_val - R_val
    if (diff % 2) == bit:
        return R_val           # đã đúng, không cần thay đổi
    else:
        new_r = R_val + 1
        # Đảm bảo không vượt giới hạn 16-bit signed
        if new_r > 32767:
            new_r = R_val - 1
        return new_r


def embed_diff(wav_in, wav_out, message):
    sentinel_msg = message + SENTINEL
    bits = [int(b) for byte in sentinel_msg.encode('utf-8')
            for b in f'{byte:08b}']

    with wave.open(wav_in, 'r') as f:
        params  = f.getparams()
        frames  = f.readframes(f.getnframes())

    total_samples = len(frames) // 2
    samples = list(struct.unpack(f'<{total_samples}h', frames))

    L = samples[0::2]
    R = list(samples[1::2])
    capacity = len(R)

    if len(bits) > capacity:
        print(f"[ERROR] Thong diep qua dai! Toi da: {capacity // 8} bytes, "
              f"can: {len(bits) // 8} bytes")
        sys.exit(1)

    modified = 0
    for i, bit in enumerate(bits):
        if i >= len(R):
            break
        new_r = adjust_for_bit(L[i], R[i], bit)
        if new_r != R[i]:
            modified += 1
        R[i] = new_r

    # Ghép lại L, R xen kẽ (interleaved)
    merged = []
    for l, r in zip(L, R):
        merged.extend([l, r])

    new_frames = struct.pack(f'<{len(merged)}h', *merged)

    with wave.open(wav_out, 'w') as fout:
        fout.setparams(params)
        fout.writeframes(new_frames)

    print(f"[SUCCESS] Da nhung {len(bits)} bits ({len(sentinel_msg)} ky tu) "
          f"vao {wav_out}")
    print(f"[INFO] So mau R bi sua doi: {modified}/{len(bits)}")
    print(f"[INFO] Thong diep: '{message}'")
    return len(bits)


if __name__ == '__main__':
    message = 'MatKhauBiMat'
    if len(sys.argv) > 1:
        message = sys.argv[1]
    bits_used = embed_diff(WAV_IN, WAV_OUT, message)
    print(f"[OK] Hoan thanh nhung LSB Differential.")
