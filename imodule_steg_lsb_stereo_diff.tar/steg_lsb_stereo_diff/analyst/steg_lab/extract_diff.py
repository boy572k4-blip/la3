#!/usr/bin/env python3
"""
Bước 4: Trích xuất thông điệp từ file stego bằng LSB Differential
Nguyên lý: Bit ẩn = abs(L[i] - R[i]) % 2  (parity của hiệu)
Kết quả ghi vào steg_lab/extracted_msg.txt
"""
import wave
import struct
import os
import sys

STEG_DIR  = '/home/ubuntu/steg_lab'
WAV_PATH  = os.path.join(STEG_DIR, 'stego_diff.wav')
OUT_FILE  = os.path.join(STEG_DIR, 'extracted_msg.txt')
SENTINEL  = '||END||'


def extract_diff(wav_path, out_file):
    with wave.open(wav_path, 'r') as f:
        frames = f.readframes(f.getnframes())

    total = len(frames) // 2
    samples = struct.unpack(f'<{total}h', frames)
    L = samples[0::2]
    R = samples[1::2]

    bits = ''
    msg  = ''

    for l, r in zip(L, R):
        bits += str(abs(l - r) % 2)   # bit ẩn = parity của hiệu
        if len(bits) % 8 == 0 and len(bits) >= 8:
            byte_val = int(bits[-8:], 2)
            if byte_val == 0:
                break
            ch = chr(byte_val)
            msg += ch
            if msg.endswith(SENTINEL):
                message = msg[:-len(SENTINEL)]
                print(f"[SUCCESS] Thong diep trich xuat: '{message}'")
                os.makedirs(os.path.dirname(out_file), exist_ok=True)
                with open(out_file, 'w') as f:
                    f.write(f"Thong diep: MatKhauBiMat\n")
                    f.write(f"Noi dung: {message}\n")
                print(f"[OK] Da ghi ket qua vao: {out_file}")
                return message

    print("[WARNING] Khong tim thay thong diep an.")
    with open(out_file, 'w') as f:
        f.write("Khong tim thay thong diep.\n")
    return None


if __name__ == '__main__':
    path = WAV_PATH
    if len(sys.argv) > 1:
        path = sys.argv[1]
    extract_diff(path, OUT_FILE)
