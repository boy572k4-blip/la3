#!/usr/bin/env python3
"""
Step 4: extract a hidden message from a stereo WAV file using LSB Differential.

Student task:
  Complete hidden_bit_from_pair().
"""
import os
import struct
import sys
import wave

STEG_DIR = "/home/ubuntu/steg_lab"
WAV_PATH = os.path.join(STEG_DIR, "stego_diff.wav")
OUT_FILE = os.path.join(STEG_DIR, "extracted_msg.txt")
SENTINEL = "||END||"


def hidden_bit_from_pair(L_val, R_val):
    # TODO: Student completes this function.
    # Hidden bit is the parity of abs(L_val - R_val).
    raise NotImplementedError("Complete hidden_bit_from_pair() first")


def extract_diff(wav_path):
    with wave.open(wav_path, "r") as f:
        frames = f.readframes(f.getnframes())

    total = len(frames) // 2
    samples = struct.unpack(f"<{total}h", frames)
    L = samples[0::2]
    R = samples[1::2]

    bits = ""
    msg = ""
    for l, r in zip(L, R):
        bits += str(hidden_bit_from_pair(l, r))
        while len(bits) >= 8:
            byte_val = int(bits[:8], 2)
            bits = bits[8:]
            if byte_val == 0:
                return None
            msg += chr(byte_val)
            if msg.endswith(SENTINEL):
                return msg[:-len(SENTINEL)]
    return None


def main():
    path = WAV_PATH
    if len(sys.argv) > 1:
        path = sys.argv[1]

    lines = []
    try:
        message = extract_diff(path)
        if message:
            lines.extend([
                "EXTRACT_DIFF_DONE",
                f"message={message}",
                "expected_message=MatKhauBiMat",
            ])
            print(f"[OK] Extracted message: {message}")
        else:
            lines.extend([
                "EXTRACT_DIFF_FAILED",
                "message=NOT_FOUND",
            ])
            print("[WARNING] Hidden message not found")
    except Exception as exc:
        lines.extend([
            "EXTRACT_DIFF_FAILED",
            f"error={type(exc).__name__}: {exc}",
        ])
        print(f"[ERROR] {exc}")

    with open(OUT_FILE, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"[OK] result saved to: {OUT_FILE}")


if __name__ == "__main__":
    main()
