#!/usr/bin/env python3
"""Tạo file stereo WAV cover cho bài lab LSB Differential Steganography"""
import wave
import struct
import math
import os
import random

STEG_DIR = '/home/ubuntu/steg_lab'
OUTPUT   = os.path.join(STEG_DIR, 'stereo_input.wav')

random.seed(42)
SAMPLE_RATE = 44100
DURATION    = 3          # giây
NUM_FRAMES  = SAMPLE_RATE * DURATION
NUM_CHANNELS = 2
SAMPWIDTH    = 2          # 16-bit

samples = []
for i in range(NUM_FRAMES):
    t = i / SAMPLE_RATE
    # Kênh trái: hỗn hợp sóng sin
    L = int(8000 * math.sin(2 * math.pi * 440 * t)
          + 3000 * math.sin(2 * math.pi * 880 * t)
          + random.randint(-200, 200))
    # Kênh phải: tương tự nhưng lệch pha
    R = int(7500 * math.sin(2 * math.pi * 440 * t + 0.3)
          + 2800 * math.sin(2 * math.pi * 880 * t + 0.1)
          + random.randint(-200, 200))
    L = max(-32768, min(32767, L))
    R = max(-32768, min(32767, R))
    samples.extend([L, R])

os.makedirs(STEG_DIR, exist_ok=True)
with wave.open(OUTPUT, 'w') as f:
    f.setnchannels(NUM_CHANNELS)
    f.setsampwidth(SAMPWIDTH)
    f.setframerate(SAMPLE_RATE)
    f.writeframes(struct.pack(f'<{len(samples)}h', *samples))

print(f"[OK] stereo_input.wav: {NUM_CHANNELS}ch, {SAMPLE_RATE}Hz, "
      f"{NUM_FRAMES} frames -> {OUTPUT}")
