#!/usr/bin/env python3
"""
Bước 1: Kiểm tra cấu trúc file WAV stereo
Kết quả ghi vào steg_lab/stereo_info.txt
"""
import wave
import struct
import os

STEG_DIR = '/home/ubuntu/steg_lab'
WAV_IN   = os.path.join(STEG_DIR, 'stereo_input.wav')
OUT_FILE = os.path.join(STEG_DIR, 'stereo_info.txt')

with wave.open(WAV_IN, 'r') as f:
    n_channels  = f.getnchannels()
    sample_rate = f.getframerate()
    samp_width  = f.getsampwidth()
    n_frames    = f.getnframes()
    frames      = f.readframes(20)        # đọc 20 frame đầu

info_lines = []
info_lines.append(f"Kenh      : {n_channels}")
info_lines.append(f"Tan so    : {sample_rate} Hz")
info_lines.append(f"Bit/mau   : {samp_width * 8}")
info_lines.append(f"So frame  : {n_frames}")

# Tách kênh trái / phải từ 20 frame đầu
samples = struct.unpack(f'<{n_channels * 20}h', frames)
L = samples[0::2]
R = samples[1::2]
diff = [a - b for a, b in zip(L, R)]

info_lines.append(f"\n10 mau dau kenh Trai (L): {list(L[:10])}")
info_lines.append(f"10 mau dau kenh Phai (R): {list(R[:10])}")
info_lines.append(f"Hieu L-R (10 mau dau)   : {diff[:10]}")
info_lines.append(f"\nNguyen ly LSB Differential:")
info_lines.append("  diff = L[i] - R[i]")
info_lines.append("  Bit can giau = 0  =>  dieu chinh de diff CHAN")
info_lines.append("  Bit can giau = 1  =>  dieu chinh de diff LE")
info_lines.append("INSPECT_STEREO_DONE")

output = '\n'.join(info_lines)
print(output)

os.makedirs(STEG_DIR, exist_ok=True)
with open(OUT_FILE, 'w') as f:
    f.write(output + '\n')

print(f"\n[OK] Da ghi ket qua vao: {OUT_FILE}")
