#!/usr/bin/env python3
"""
Bước 5: So sánh khả năng bị phát hiện giữa LSB trực tiếp và LSB Differential
bằng kiểm định Chi-square trên phân phối bit LSB của kênh phải (R).
Kết quả ghi vào steg_lab/chi_compare.txt
"""
import wave
import struct
import os
import sys
import math

STEG_DIR   = '/home/ubuntu/steg_lab'
CLEAN_WAV  = os.path.join(STEG_DIR, 'stereo_input.wav')
STEGO_WAV  = os.path.join(STEG_DIR, 'stego_diff.wav')
OUT_FILE   = os.path.join(STEG_DIR, 'chi_compare.txt')


def read_R_channel(wav_path):
    """Đọc kênh phải (R) từ file WAV stereo"""
    with wave.open(wav_path, 'r') as f:
        frames = f.readframes(f.getnframes())
    total   = len(frames) // 2
    samples = struct.unpack(f'<{total}h', frames)
    return samples[1::2]   # chỉ số lẻ = kênh phải


def chi_square_lsb(samples):
    """
    Chi-square kiểm định phân phối bit LSB của kênh R.
    Tính tần số bit 0 và bit 1 từ các cặp (2k, 2k+1) theo giá trị mẫu mod 2.
    Trả về (chi2_stat, p_value_approx, count_0, count_1)
    """
    count_0 = sum(1 for s in samples if abs(s) % 2 == 0)
    count_1 = sum(1 for s in samples if abs(s) % 2 == 1)
    total   = count_0 + count_1
    expected = total / 2.0

    # Chi-square với 1 bậc tự do
    chi2 = ((count_0 - expected)**2 + (count_1 - expected)**2) / expected

    # Xấp xỉ p-value từ Chi-square distribution (1 dof)
    # p = 1 - CDF_chi2(chi2, 1) ≈ erfc(sqrt(chi2/2))
    p_value = math.erfc(math.sqrt(chi2 / 2.0))

    return chi2, p_value, count_0, count_1


def analyze(label, wav_path):
    samples = read_R_channel(wav_path)
    chi2, p_val, c0, c1 = chi_square_lsb(samples)
    lines = [
        f"\n=== {label} ===",
        f"  File         : {wav_path}",
        f"  Tong mau R   : {len(samples)}",
        f"  LSB = 0      : {c0}  ({100*c0/len(samples):.2f}%)",
        f"  LSB = 1      : {c1}  ({100*c1/len(samples):.2f}%)",
        f"  Chi2 stat    : {chi2:.4f}",
        f"  pvalue       : {p_val:.6f}",
    ]
    if p_val < 0.05:
        lines.append("  KET LUAN     : p-value < 0.05 => CO du lieu an!")
    else:
        lines.append("  KET LUAN     : p-value >= 0.05 => Khong co du lieu an.")
    return '\n'.join(lines), p_val


def main():
    lines = ["=== CHI-SQUARE SO SANH LSB DISTRIBUTION ===\n"]
    lines.append("Phan tich phan phoi bit LSB kenh phai (R) cua 2 file:\n")

    r_clean, pv_clean = analyze("FILE GOC (stereo_input.wav)", CLEAN_WAV)
    r_stego, pv_stego = analyze("FILE STEGO LSB DIFFERENTIAL (stego_diff.wav)", STEGO_WAV)

    lines.append(r_clean)
    lines.append(r_stego)
    lines.append("\n=== NHAN XET ===")
    lines.append(f"  File goc  pvalue={pv_clean:.6f}  => "
                 f"{'CO' if pv_clean < 0.05 else 'KHONG CO'} du lieu an")
    lines.append(f"  Stego diff pvalue={pv_stego:.6f}  => "
                 f"{'CO' if pv_stego < 0.05 else 'KHONG CO'} du lieu an")
    lines.append("\nLy do LSB Differential kho bi phat hien hon LSB truc tiep:")
    lines.append("  - Khong thay doi phan phoi LSB cua tung kenh rieng le.")
    lines.append("  - Thong tin duoc ma hoa trong su KHAC BIET giua 2 kenh.")
    lines.append("  - Phan tich Chi-square tren 1 kenh don le se khong phat hien.")

    output = '\n'.join(lines)
    print(output)

    os.makedirs(STEG_DIR, exist_ok=True)
    with open(OUT_FILE, 'w') as f:
        f.write(output + '\n')
    print(f"\n[OK] Da ghi ket qua vao: {OUT_FILE}")


if __name__ == '__main__':
    main()
