#!/bin/bash
service ssh start 2>/dev/null

# Thiết lập metadata cho Labtainer grader
mkdir -p /home/ubuntu/.local
echo "steg_lsb_stereo_diff_seed"  > /home/ubuntu/.local/.seed
echo "student@labtainer.local"    > /home/ubuntu/.local/.email
echo "steg_lsb_stereo_diff"       > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

# Tạo /var/labtainer/did_param (Labtainer yêu cầu)
mkdir -p /var/labtainer
touch /var/labtainer/did_param

# Tạo thư mục steg_lab và generate file WAV cover
mkdir -p /home/ubuntu/steg_lab
chown -R ubuntu:ubuntu /home/ubuntu/steg_lab

if [ ! -f /home/ubuntu/steg_lab/stereo_input.wav ]; then
    python3 /home/ubuntu/steg_lab/generate_stereo.py 2>/dev/null
    chown ubuntu:ubuntu /home/ubuntu/steg_lab/stereo_input.wav 2>/dev/null
fi

tail -f /dev/null
