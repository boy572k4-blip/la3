#!/usr/bin/env python3
import os
import sys


def check_file_contains(student_dir, container, rel_path, keyword):
    candidates = [
        os.path.join(student_dir, container, "home", "ubuntu", rel_path),
        os.path.join(student_dir, container, rel_path),
    ]
    for path in candidates:
        if os.path.isfile(path):
            try:
                return keyword.lower() in open(path, errors="ignore").read().lower()
            except Exception:
                return False
    return False


def main():
    if len(sys.argv) < 2:
        print("Usage: grade.py <student_dir>")
        sys.exit(1)

    student_dir = sys.argv[1]
    container = "steg_lsb_stereo_diff.analyst.student"
    checks = {
        "inspect_stereo": ("steg_lab/stereo_info.txt", "INSPECT_STEREO_DONE"),
        "embed_diff": ("steg_lab/embed_result.txt", "EMBED_DIFF_DONE"),
        "extract_diff": ("steg_lab/extracted_msg.txt", "EXTRACT_DIFF_DONE"),
        "chi_compare": ("steg_lab/chi_compare.txt", "CHI_COMPARE_DONE"),
        "steg_report": ("steg_lab/bao_cao.txt", "STEREO_DIFF_REPORT_DONE"),
        "student_answer": ("steg_lab/analysis_answer.txt", "STUDENT_STEREO_DIFF_DONE"),
    }

    labels = {
        "inspect_stereo": "inspect_stereo",
        "embed_diff": "embed_diff",
        "extract_diff": "extract_diff",
        "chi_compare": "chi_compare",
        "steg_report": "steg_report",
        "student_answer": "student_answer",
    }

    for key, (path, marker) in checks.items():
        mark = "Y" if check_file_contains(student_dir, container, path, marker) else "N"
        print(f" {mark} -  {labels[key]}")


if __name__ == "__main__":
    main()
