#!/usr/bin/env python3
"""
Grading script for steg_lsb_stereo_diff lab.
Called by Labtainer instructor.py after extracting student artifacts.
Args: student_dir lab_name
"""
import os
import sys


def check_file_contains(student_dir, container, rel_path, keyword):
    """Kiểm tra file tồn tại và chứa keyword"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path  = os.path.join(student_dir, container, rel_path)
    for path in [full_path, alt_path]:
        if os.path.isfile(path):
            try:
                content = open(path, errors='ignore').read()
                return keyword.lower() in content.lower()
            except Exception:
                pass
    return False


def check_file_size(student_dir, container, rel_path, min_bytes=1):
    """Kiểm tra file tồn tại và có kích thước >= min_bytes"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    alt_path  = os.path.join(student_dir, container, rel_path)
    for path in [full_path, alt_path]:
        if os.path.isfile(path):
            return os.path.getsize(path) >= min_bytes
    return False


def main():
    if len(sys.argv) < 2:
        print("Usage: grade.py <student_dir>")
        sys.exit(1)

    student_dir = sys.argv[1]
    results = {}

    # Bước 1: stereo_info.txt chứa "Kenh"
    results['inspect_stereo'] = check_file_contains(
        student_dir, 'steg_lsb_stereo_diff.analyst.student',
        'steg_lab/stereo_info.txt', 'Kenh')

    # Bước 2: stego_diff.wav tồn tại và có kích thước > 0
    results['embed_diff'] = check_file_size(
        student_dir, 'steg_lsb_stereo_diff.analyst.student',
        'steg_lab/stego_diff.wav', 1)

    # Bước 3: extracted_msg.txt chứa thông điệp
    results['extract_diff'] = check_file_contains(
        student_dir, 'steg_lsb_stereo_diff.analyst.student',
        'steg_lab/extracted_msg.txt', 'MatKhauBiMat')

    # Bước 4: chi_compare.txt chứa kết quả thống kê
    results['chi_compare'] = check_file_contains(
        student_dir, 'steg_lsb_stereo_diff.analyst.student',
        'steg_lab/chi_compare.txt', 'pvalue')

    # Bước 5: bao_cao.txt chứa báo cáo
    results['steg_report'] = check_file_contains(
        student_dir, 'steg_lsb_stereo_diff.analyst.student',
        'steg_lab/bao_cao.txt', 'LSB Differential')

    labels = {
        'inspect_stereo': 'B1 - Ghi stereo_info.txt',
        'embed_diff':     'B2 - Tao stego_diff.wav',
        'extract_diff':   'B3 - Ghi extracted_msg.txt',
        'chi_compare':    'B4 - Ghi chi_compare.txt',
        'steg_report':    'B5 - Ghi bao_cao.txt',
    }

    for key, label in labels.items():
        mark = 'Y' if results[key] else 'N'
        print(f' {mark} -  {label}')


if __name__ == '__main__':
    main()
