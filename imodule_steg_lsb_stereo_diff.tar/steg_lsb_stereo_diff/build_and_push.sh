#!/bin/bash
REGISTRY="r3xonx"
LAB="steg_lsb_stereo_diff"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Build & Push: $LAB"
echo " $REGISTRY/${LAB}.analyst.student"
echo "=============================================="

docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login that bai!" && exit 1

echo "[BUILD] analyst..."
cd "$SCRIPT_DIR/analyst" && docker build -t "$REGISTRY/${LAB}.analyst.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build analyst that bai!" && exit 1

echo "[PUSH] analyst..."
docker push "$REGISTRY/${LAB}.analyst.student:latest"
[ $? -ne 0 ] && echo "[ERROR] Push analyst that bai!" && exit 1

echo "=============================================="
echo " HOAN THANH!"
echo " Image: $REGISTRY/${LAB}.analyst.student:latest"
echo "=============================================="
